import javax.swing.*;

public class EnigmaGUI {
    public static void main(String[] args) {    // main
       EnigmaFrame frame = new EnigmaFrame();
        frame.setVisible(true);
    }
}